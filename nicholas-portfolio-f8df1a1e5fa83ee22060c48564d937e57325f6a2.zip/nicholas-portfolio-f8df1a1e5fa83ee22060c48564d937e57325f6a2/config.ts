// Project configuration placeholder
export default {};
